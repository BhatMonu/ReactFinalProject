import React, { Component } from 'react';
import history from '../history'
class ErrorScreen extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    return (
      <div class="container">
        <label>ERROR OCCURED</label> &nbsp; &nbsp; &nbsp;
        <input type="button" onClick={() => this.goBack()} value="Go to previous screen" />
      </div>
    );
  }
  goBack() {
    history.goBack()
  }
}

export default ErrorScreen;
