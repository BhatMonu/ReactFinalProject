class serviceClass {
    // API call to get all permanent users.
    loginAuth(object, callback) {
        fetch('http://localhost:4070/api/users/auth', {
            method: 'post',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
            }),
            body: JSON.stringify(object)
        }).then(response => response.json())
            .then(resData => {
                callback(null, resData);
                console.log(JSON.stringify(resData))
            })

    }


    getAllPermanentUsers(token, callback) {
        fetch('http://localhost:4070/api/users/allUsers', {
            method: 'GET',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            })
        }).then(response => response.json())
            .then(resData => {
                callback(null, resData);
            }).catch(err => console.log(error(err)));
    }
    // API call to get all temporary users details waiting for approval from admin.
    getAllTemporaryUsers(token, callback) {
        fetch('http://localhost:4070/api/users/allPendingUsers', {
            method: 'GET',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            })

        }).then(response => response.json())
            .then(resData => {
                console.log("All pending Users array", JSON.stringify(resData.data))
                callback(null, resData);
            }).catch(err => console.log(error(err)));
    }

    //API to create user by admin step 1
    createUserByAdminStep1(token, user, callback) {
        fetch('http://localhost:4070/api/users/create', {
            method: 'post',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token

            }),
            body: JSON.stringify(user)
        }).then(response => response.json())
            .then(resData => {
                console.log(JSON.stringify("create 1", resData));
                callback(null, resData);
                //  alert("User created successfully")
            });
    }

    //API to create user by admin step 2.
    createUserByAdminStep2(token, personalInfo, callback) {
        fetch('http://localhost:4070/api/addpersonalInfo', {
            method: 'post',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token

            }),
            body: JSON.stringify(personalInfo)
        }).then(response => response.json())
            .then(resData => {
                console.log(JSON.stringify(resData));
                callback(null, resData);
            });
    }

    // create user by Operator and send it to Admin for approval until then keep the info in temporary data base
    createUserByOperatorStep1(token, user, callback) {
        fetch('http://localhost:4070/api/users/createtemp', {
            method: 'post',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token

            }),
            body: JSON.stringify(user)
        }).then(response => response.json())
            .then(resData => {
                console.log("Create by operator api 1", JSON.stringify(resData));
                callback(null, resData);
            });
    }
    createUserByOperatorStep2(token, personalInfo, callback) {
        fetch('http://localhost:4070/api/temp/addpersonalInfo', {
            method: 'post',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token

            }),
            body: JSON.stringify(personalInfo)
        }).then(response => response.json())
            .then(resData => {
                //alert("User created successfully and request is sent to Admin for approval");
                console.log("Create by operator api 2", JSON.stringify(resData));
                callback(null, resData);
            });

    }
    //API call to get login user's data
    getYourProfileData(token, id, callback) {
        fetch(`http://localhost:4070/api/user/getPersonalInfo/${id}`, {
            method: 'get',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            })
        }).then(response => response.json())
            .then(resData => {
                console.log(JSON.stringify(resData))
                callback(null, resData);
            });
    }

    // API call to update existing user details
    updateExistingUsersData(token, id, user, callback) {
        fetch(`http://localhost:4070/api/updateuser/${id}`, {
            method: 'put',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            }),
            body: JSON.stringify(user)
        }).then(response => response.json())
            .then(resData => {
                console.log("Updated User details", JSON.stringify(resData));
                callback(null, resData);
            });

    }
    //API call to reject any update requests received from operator or AccessUser
    rejectRequest(token, id, callback) {
        fetch(`http://localhost:4070/api/deleteTempUser/${id}`, {
            method: 'delete',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            })
        }).then(response => response.json())
            .then(resData => {
                callback(null, resData);
                // alert("Request rejected");
            }).catch(err => console.log(error(err)));
    }

    // API call's to Approve update requests received from Operator or Access User
    approveRequest1(token, userData, callback) {
        fetch("http://localhost:4070/api/users/approval/one", {
            method: 'post',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            }),
            body: JSON.stringify(userData)
        }).then(response => response.json())
            .then(resData => {
                console.log("approval 1 User details", JSON.stringify(resData));
                callback(null, resData);
            })


    }
    approveRequest3(token, userData, callback) {
        fetch("http://localhost:4070/api/users/approval/three", {
            method: 'delete',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            }),
            body: JSON.stringify(userData)
        }).then(response => response.json())
            .then(resp => {
                // alert("New user creation request approved");

                console.log("approval 3 User details", JSON.stringify(resp));
                callback(null, resp);
            })
    }

    approveRequest2(token, userData, callback) {
        fetch("http://localhost:4070/api/users/approval/two", {
            method: 'put',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            }),
            body: JSON.stringify(userData)
        }).then(response => response.json())
            .then(resData => {
                callback(null, resData);
            })
    }

    // API to delete user by admin
    deleteUserByAdmin(token, id, callback) {
        fetch(`http://localhost:4070/api/deleteuser/${id}`, {
            method: 'delete',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            })
        }).then(response => response.json())
            .then(resData => {
                console.log("deleted User details", JSON.stringify(resData));
                callback(null, resData);
            });
    }

    // API to update user by Admin
    updateUserByAdmin(token, id, user, callback) {
        fetch(`http://localhost:4070/api/updateuseradmin/${id}`, {
            method: 'put',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            }),
            body: JSON.stringify(user)
        }).then(response => response.json())
            .then(resData => {
                callback(null, resData);
                console.log("Updated User details", JSON.stringify(resData))
            });
    }

    // API to update user by Operator or AccessUser
    updateUserByOthers(token, id, user, callback) {
        fetch(`http://localhost:4070/api/updateuser/${id}`, {
            method: 'put',
            headers: new Headers({
                'Content-Type': 'application/json',
                "Access-Control-Allow-Credentials": "true",
                "Authorization": "bearer" + " " + token
            }),
            body: JSON.stringify(user)
        }).then(response => response.json())
            .then(resData => {
                callback(null, resData);
                console.log("Updated User details", JSON.stringify(resData))
            });

    }
}

export default serviceClass;