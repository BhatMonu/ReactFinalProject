var express = require("express");
var path = require("path");
var jwt = require("jsonwebtoken");
var bodyParser = require("body-parser");

var mongoose = require("mongoose");
mongoose.Promise = global.Promise;

var cors = require("cors");
var instance = express();
var systemInfo = "";
instance.use(
    express.static(path.join(__dirname, "./../node_modules/jquery/dist/"))
);

var os = require('os');
var networkInterfaces = os.networkInterfaces();
var array = [];
var info = "";
array.push(networkInterfaces);
systemInfo = Object.values(array[0]).map((p, i = 0) => (
    (i == 0) && {

        ipAddress: p[1].address,
        sysytemName: p[1]
    }),
)

var router = express.Router();
instance.use(router);
instance.use(bodyParser.urlencoded({ extended: false }));
instance.use(bodyParser.json())
instance.use(cors());

router.get("/home", function (req, resp) {
    resp.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    });
});

mongoose.connect("mongodb://localhost/PersonalInformation",
    { useNewUrlParser: true });

var dbConnect = mongoose.connection;
if (!dbConnect) {
    console.log("Connection is not established");
    return;
}

var PersonalInfoSchema = mongoose.Schema({
    PersonalUniqueID: String,
    FullName: Object,
    Gender: String,
    DateOfBirth: String,
    Age: String,
    Address: Object,
    City: String,
    State: String,
    PinCode: String,
    PhoneNo: String,
    PhysicalDisability: String,
    MaritalStatus: String,
    EducationStatus: String,
    BirthSign: String
});

var userSchema = mongoose.Schema({
    UserID: String,
    UserName: String,
    Password: String,
    Role: String,
    RoleID: String,
    EmailAddress: String

});


var userTempSchema = mongoose.Schema({
    UserID: String,
    UserName: String,
    Password: String,
    Role: String,
    RoleID: String,
    EmailAddress: String

});

var tempSchema = mongoose.Schema({
    PersonalUniqueID: String,
    FullName: Object,
    Gender: String,
    DateOfBirth: String,
    Age: String,
    Address: Object,
    City: String,
    State: String,
    PinCode: String,
    PhoneNo: String,
    PhysicalDisability: String,
    MaritalStatus: String,
    EducationStatus: String,
    BirthSign: String
});

var loginSchema = mongoose.Schema({
    LoginStatusId: String,
    UserName: String,
    LoginFrom: Object,
    DateTime: String,
    IPAddress: String
})

var personalInfoModel = mongoose.model("PersonalInfo", PersonalInfoSchema, "PersonalInfo")
var uModel = mongoose.model("Users", userSchema, "Users")
var tempModel = mongoose.model("tempCollection", tempSchema, "tempCollection")
var userTempModel = mongoose.model("userTempCollection", userTempSchema, "userTempCollection")
var loginSchemaModel = mongoose.model("LoginStatus", loginSchema, "LoginStatus")
var jwtSettings = {
    jwtSecret: "dbcsbiobc0708hdfcyesbombob"
};

instance.set("jwtSecret", jwtSettings.jwtSecret);
var tokenStore = "";
// 7. authenticate user 
instance.post("/api/users/auth", function (request, response) {
    var user = {
        UserName: request.body.UserName,
        Password: request.body.Password,
    };

    console.log("In Auth User ", user);
    uModel.findOne({ UserName: request.body.UserName }, function (err, usr) {
        if (err) {

            response.send({
                statusCode: 202,
                message: "Sorry!Error occured"
            });
        }
        //  if user not found the respond error 
        if (!usr) {

            response.send({
                statusCode: 404,
                message: "Sorry!User is not available"
            });
        } else if (usr) {
            // 7b. user is available but password not match the 
            // respond error 
            console.log("In else if " + JSON.stringify(usr));
            if (usr.Password != user.Password) {
                // console.log("in password check");
                response.send({
                    statusCode: 404,
                    message: "Sorry!User Name and Password does not match"
                });
            } else {

                var token = jwt.sign({ usr }, instance.get("jwtSecret"), {
                    expiresIn: 9500
                });

                var formatted = new Date().toLocaleString();
                loginStatusData = {
                    LoginStatusId: usr.UserID,
                    UserName: request.body.UserName,
                    LoginFrom: systemInfo[0].sysytemName,
                    DateTime: formatted,
                    IPAddress: systemInfo[0].ipAddress
                };
                console.log("loginStatusData", loginStatusData);
                //  loginSchemaModel.create
                loginSchemaModel.create(loginStatusData, function (err, res) {
                    if (err) {
                        response.statusCode = 500;
                        response.send({ statusCode: response.statusCode, message: err });
                    }

                });
                console.log("in jwt", token);
                // save token globally 
                tokenStore = token;
                response.send({
                    statusCode: 200,
                    authenticated: true,
                    message: "Login Success",
                    token: token,
                    data: usr
                });
            }
        }
    });
});


instance.post("/api/users/create", function (request, response) {

    var user = {
        UserID: request.body.UserID,
        UserName: request.body.UserName,
        Password: request.body.Password,
        EmailAddress: request.body.EmailAddress,
        Role: request.body.Role,
        RoleID: request.body.RoleID
    };
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            uModel.create(user, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ statusCode: response.statusCode, message: err });
                }
                response.send({ statusCode: 200, message: res });
            });
        }
    });
});


instance.post("/api/users/createtemp", function (request, response) {

    var user = {
        UserID: request.body.UserID,
        UserName: request.body.UserName,
        Password: request.body.Password,
        EmailAddress: request.body.EmailAddress,
        Role: request.body.Role,
        RoleID: request.body.RoleID
    };
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            userTempModel.create(user, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ statusCode: response.statusCode, message: err });
                }
                response.send({ statusCode: 200, message: res });
            });
        }
    });
});

instance.post("/api/addpersonalInfo", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var createdByUserRole = request.body.createdByRole;
    console.log("createdByUserRole", createdByUserRole);
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        Gender: request.body.Gender,
        Age: request.body.Age,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        DateOfBirth: request.body.DateOfBirth,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PhoneNo: request.body.PhoneNo,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign,
        PhysicalDisability: request.body.PhysicalDisability,
        PinCode: request.body.PinCode
    };
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            personalInfoModel.create(obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({ status: 200, data: res });
            });


        }
    });
});

instance.post("/api/temp/addpersonalInfo", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var createdByUserRole = request.body.createdByRole;
    console.log("createdByUserRole", createdByUserRole);
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            tempModel.create(obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({ status: 200, data: res });
            });


        }
    });
});


instance.get("/api/user/getPersonalInfo/:id", function (request, response) {
    var condition = {
        PersonalUniqueID: request.params.id
    }
    var tokenReceived = request.headers.authorization.split(" ")[1];
    console.log("tokenReceived", tokenReceived)

    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            // 8c. decode the request 
            request.decoded = decoded;
            personalInfoModel.find(condition, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ status: response.statusCode, error: err });
                }
                response.send({ status: 200, data: res });
            });
        }
    });
});

instance.get("/api/users/allUsers", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    console.log("tokenReceived", tokenReceived)
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            request.decoded = decoded;
            personalInfoModel.find().exec(function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ status: response.statusCode, error: err });
                }
                response.send({ status: 200, data: res });
            });
        }
    });
});


instance.get("/api/users/allPendingUsers", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    console.log("tokenReceived", tokenReceived)
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            console.log("in auth success");
            request.decoded = decoded;
            tempModel.find().exec(function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send({ status: response.statusCode, error: err });
                }
                response.send({ status: 200, data: res });
            });
        }
    });
});


//api to update personal detail into db by Admin
instance.put("/api/updateuseradmin/:id", function (request, response) {
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    var condition = {
        PersonalUniqueID: request.params.id
    }
    console.log("condition", JSON.stringify(condition));
    console.log("obj", JSON.stringify(obj));
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            personalInfoModel.updateOne(condition, obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({
                    status: 200,
                    data: res
                });
            });

        }
    });
});
//output -> {"status":200,"data":{"n":1,"nModified":1,"ok":1}}


//api to update personal detail into db by operator and accessuser
instance.put("/api/updateuser/:id", function (request, response) {
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    var condition = {
        PersonalUniqueID: request.params.id
    }
    console.log("condition", JSON.stringify(condition));
    console.log("obj", JSON.stringify(obj));
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            tempModel.create(obj, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({ status: 200, data: res });
            });

        }
    });
});


//api to delete data  from db
instance.delete("/api/deleteuser/:id", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var condition = {
        PersonalUniqueID: request.params.id
    }
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in delete verify");
        if (err) {
            console.log("in delete auth error");
            response.send({
                success: false, message: "Token verification failed in delete"
            });
        } else {
            request.decoded = decoded;
            personalInfoModel.deleteOne(condition, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                }
                response.send({
                    status: 200,
                    data: res
                });
            });
        }
    });
});
// delete/reject temp data request with admin login
instance.delete("/api/deleteTempUser/:id", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var condition = {
        PersonalUniqueID: request.params.id
    }
    var condition1 = {
        UserID: request.params.id
    }
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in delete verify");
        if (err) {
            console.log("in delete auth error");
            response.send({
                success: false, message: "Token verification failed in delete"
            });
        } else {
            request.decoded = decoded;
            tempModel.deleteOne(condition, function (err, res) {
                if (err) {
                    response.statusCode = 500;
                    response.send(err);
                } else {
                    userTempModel.deleteOne(condition1, function (err, res) {
                        if (err) {
                            response.statusCode = 500;
                            response.send(err);
                        } else {
                            response.send({
                                status: 200,
                                data: res
                            });
                        }
                    });
                }
            });
        }
    });
});



// Approve operator's update or add request


instance.post("/api/users/approval/one", function (request, response) {
    //  alert(request.body.PersonalUniqueID);
    var obj = request.body;
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            console.log("in verify");
            tempModel.findOne({ PersonalUniqueID: request.body.PersonalUniqueID }, function (err, res) {
                if (err) {
                    response.send({
                        statusCode: 202,
                        message: "Sorry! Error occured"
                    });
                } else if (res) {
                    userTempModel.findOne({ UserID: request.body.PersonalUniqueID }, function (err1, res1) {
                        if (err1) {
                            response.send({
                                statusCode: 202,
                                message: "Sorry! Error occured"
                            });
                        } else {
                            if (!res1) {
                                console.log("in ! res");
                                response.send({
                                    statusCode: 209,
                                    message: "Sorry!Data is not available"
                                });
                            } else if (res1) {
                                console.log("in res1", JSON.stringify(res1));
                                response.send({
                                    statusCode: 200
                                });
                            }

                        }
                        // response.send({
                        //     statusCode: 200
                        // });
                    });
                }
            });
        }
    });
});


instance.put("/api/users/approval/two", function (request, response) {
    console.log(request.body.PersonalUniqueID);
    var obj = {
        PersonalUniqueID: request.body.PersonalUniqueID,
        FullName: {
            FirstName: request.body.FullName.FirstName,
            MiddleName: request.body.FullName.MiddleName,
            LastName: request.body.FullName.LastName,
        },
        Gender: request.body.Gender,
        DateOfBirth: request.body.DateOfBirth,
        Age: request.body.Age,
        Address: {
            AddressLine1: request.body.Address.AddressLine1,
            AddressLine2: request.body.Address.AddressLine2,
            AddressLine3: request.body.Address.AddressLine3
        },
        City: request.body.City,
        State: request.body.State,
        PinCode: request.body.PinCode,
        PhoneNo: request.body.PhoneNo,
        PhysicalDisability: request.body.PhysicalDisability,
        MaritalStatus: request.body.MaritalStatus,
        EducationStatus: request.body.EducationStatus,
        BirthSign: request.body.BirthSign
    };
    var tokenReceived = request.headers.authorization.split(" ")[1];
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in verify");
        if (err) {
            console.log("in auth error");
            response.send({
                success: false, message: "Token verification failed"
            });
        } else {
            request.decoded = decoded;
            console.log("in verify");
            personalInfoModel.updateOne({ PersonalUniqueID: request.body.PersonalUniqueID }, obj, function (err2, res2) {
                if (err2) {
                    response.statusCode = 500;
                    response.send(err2);
                }
                else if (res2) {
                    response.send({
                        statusCode: 200,
                        data: res2
                    });
                }

            });
        }
    });
});



instance.delete("/api/users/approval/three", function (request, response) {
    var tokenReceived = request.headers.authorization.split(" ")[1];
    var condition = {
        PersonalUniqueID: request.body.PersonalUniqueID
    }
    var condition1 = {
        UserID: request.body.PersonalUniqueID
    }
    jwt.verify(tokenReceived, instance.get("jwtSecret"), function (err, decoded) {
        console.log("in delete verify");
        if (err) {
            console.log("in delete auth error");
            response.send({
                success: false, message: "Token verification failed in delete"
            });
        } else {
            request.decoded = decoded;
            console.log("in verify");
            tempModel.deleteOne(condition, function (err, res) {
                if (err) {
                    response.send({
                        statusCode: 202,
                        message: "Sorry! Error occured"
                    });
                } else if (res) {

                    userTempModel.deleteOne(condition1, function (err1, res1) {
                        if (err1) {
                            response.send({
                                statusCode: 202,
                                message: "Sorry! Error occured"
                            });
                        }
                        response.send({
                            statusCode: 200
                        });
                    });
                }
            });
        }
    });
});

//6. start listening
instance.listen(4070, function () {
    console.log("start listening on port 4070")
})
