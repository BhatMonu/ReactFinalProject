import React, { Component } from 'react';
import { Router, Switch, Route, Link } from 'react-router-dom';
import Login from './components/Login';
import Profile from './components/Profile';
import ErrorScreen from './components/Error'
import history from './history'
import ActionScreen from './components/ActionsScreen';
class App extends Component {
    render() {
        return (
            <Router history={history}>
                <Switch>
                    <Route exact path='/' component={Login} />
                    <Route path='/adminactions' component={ActionScreen} />
                    <Route path='/profile' component={Profile} />
                    <Route path='/error' component={ErrorScreen} />
                </Switch>
            </Router>
        );
    }
}

export default App;
