import React, { Component } from 'react';
import history from '../history'
import serviceClass from '../services/services.js';
import {
  Card, CardBody
} from 'reactstrap';
const ScreenHeight = screen.height;
const ScreenWidth = screen.width;
const imgMyimageexample = require('./../images.jpg');
const divStyle = {
  height: ScreenHeight,
  backgroundImage: `url(${imgMyimageexample})`,
  backgroundSize: 'cover',
  paddingTop: ScreenHeight / 5
};
class Login extends Component {
  constructor(props) {
    super(props)
    this.state = {
      userName: "",
      password: "",
      authenticationStatus: "",
      authenticationMessage: "",
      authenticationToken: "",
      authenticatedUserData: {},
      UserId: "",
      date: ""
    }
    this.serve = new serviceClass();
    this.signIn = this.signIn.bind(this);
    this.changeUserName = this.changeUserName.bind(this);
    this.changePassword = this.changePassword.bind(this);
  }

  render() {
    return (
      <div style={divStyle}>
        <Card style={{
          height: ScreenHeight / 3, width: ScreenWidth / 2.5,
          marginLeft: ScreenWidth / 4, borderWidth: "5px",
          backgroundImage: "images.jpg",
        }}>
          <CardBody>
            <div>
              <label>Username: </label> &nbsp;
                  <input type="text" required value={this.state.userName} onChange={this.changeUserName}
                style={{ width: ScreenWidth / 4, height: ScreenHeight / 20, paddingLeft: 10, paddingRight: 10, borderRadius: 50 }} /> &nbsp;
              </div>
            <br />
            <div>
              <label>Password:</label> &nbsp; &nbsp;
                  <input type="password" required value={this.state.password} onChange={this.changePassword}
                style={{ width: ScreenWidth / 4, height: ScreenHeight / 20, paddingLeft: 10, paddingRight: 10, borderRadius: 50 }} /> &nbsp;
              </div>
            <br />
            <div>
              &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <input type="button" className="btn btn-success" value="Sign In"
                onClick={this.signIn} />
            </div>
          </CardBody>

        </Card >
      </div>
    );
  }
  changeUserName(event) {
    this.setState({ userName: event.target.value });
    //   this.setState({});
  }
  changePassword(event) {
    this.setState({ password: event.target.value });
  }
  signIn() {
    if (this.state.userName != "" && this.state.password != "" &&
      this.state.userName != undefined && this.state.password != undefined &&
      this.state.userName != null && this.state.password != null) {
      var object = {
        UserName: this.state.userName,
        Password: this.state.password
      }
      this.serve.loginAuth(object, (err, resData) => {
        if (err) {
          history.push('./error');
        } else {
          if (resData.statusCode == 200) {
            this.setState({ authenticationStatus: resData.authenticated }); //this is an asynchronous function
            this.setState({ authenticationMessage: resData.message });
            this.setState({ authenticationToken: resData.token });
            this.setState({ authenticatedUserData: resData.data });
            if (this.state.authenticationToken != "" &&
              this.state.authenticationToken != undefined) {
              var data = {
                authenticatedUserData: this.state.authenticatedUserData,
                authenticationToken: this.state.authenticationToken
              }
              history.push('/profile', data);
            }
          } else {
            alert(JSON.stringify(resData.message));
          }
        }
      })
    } else {
      alert("Please enter Username and Password")
    }
  }
}

export default Login;
