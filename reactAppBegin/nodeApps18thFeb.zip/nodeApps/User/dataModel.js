//Custom Node module
module.exports = {
    getData: function (productModel, callback) {
        productModel.find().exec(function (err, res) {
            //6b. if error occured the respond error
            if (err) {
                callback(err);
            }
            callback(null, res);
        });
    },
    addData: function (data, callback) {

    },
    updateData: function (data, callback) {

    },
    deleteData: function (data, callback) {

    }
};