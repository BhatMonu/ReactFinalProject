//Custom Node module
module.exports = {
    getData: function (productModel, callback) {
        productModel.find().exec(function (err, res) {
            //6b. if error occured the respond error
            if (err) {
                callback(err);
            }
            callback(null, res);
        });
    },
    addData: function (data, callback) {

    },
    updateData: function (data, callback) {

    },
    deleteData: function (data, callback) {

    }
};


// getData: function (Products) {
//     return Products;
// },
// addData: function (prod) {
//     Products.push(prod);
//     return Products;
// },
// updateData: function (prd) {
//     for (const val of Products) {
//         if (val.id == prd.id) {
//             val.name = prd.name;
//         }
//     }
//     return Products;
// },
// deleteData: function (id) {
//     for (const val of Products) {
//         if (val.id == id) {
//             Products.pop(val);
//         }
//     }
//     return `Records of ${id} Delted Succefully`;
// }