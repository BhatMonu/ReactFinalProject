module.exports = {
    validateUser: function (req, res) {
        // var userdata = {
        //     UserId: req.body.UserId,
        //     Password: req.body.Password,
        // }
        var authValues = req.headers.authorization;
        //5b. Process values
        if (authValues) {
            var credentials = authValues.split(" ")[1];
            var data = credentials.split(":");
            var userName = data[0];
            var password = data[1];
            //5c. may accesss usermodel from db?
            if (userName == "Anu" && password == "Anu") {
                // res.send(JSON.stringify(dataModel.getData()));
                return true;

            } else {
                return false;
            }
        } else {
            return false;
        }

    },
    // createUser: () => {
    //     userModel.create(userdata, function (err, result) {
    //         if (err) {
    //             res.statusCode = 500;
    //             res.send({
    //                 status: res.statusCode,
    //                 error: err
    //             });
    //         }
    //         console.log("result" + JSON.stringify(result));
    //         res.send({
    //             status: 200,
    //             data: result
    //         });
    //     });
    // }

}