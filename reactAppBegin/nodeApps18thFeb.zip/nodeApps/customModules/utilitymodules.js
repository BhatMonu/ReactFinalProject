var str1 = "";
var res = "";
exports.caseUtility = function (str, choice) {
    str1 = str;
    if (choice === "U") {
        return str1.toUpperCase();
    }
    if (choice === "L") {
        return str1.toLowerCase();
    }
    return str1;
};

exports.reverse = function () {
    for (var i = str1.length; i > 0; i--) {
        res += str1[i];
    }
    return res;
}