
//var userModel = require("./userModel")
var Products;
var data;

module.exports = {
    getAuthorizationStatus(value) {
        data = value;
        console.log("from dal", data);
    }
};
if (data) {
    module.exports = {
        getProductArray(res) {
            Products = res;
        },
        getData: function () {
            return Products;
        },
        addData: function (prd) {
            Products.push(prd);
            return Products;
        },
        updateData: function (prd) {
            for (const val of Products) {
                if (val.id == prd.id) {
                    val.name = prd.name;
                }
            }
            //  Products[index] = prd;
            return Products;
        },
        deleteData: function (id) {
            for (const val of Products) {
                if (val.id == id) {
                    Products.pop(val);
                }
            }
            return Products;
        }

    };
}

