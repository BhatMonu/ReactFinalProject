var dalModel = require("./dal")
module.exports = {
    validateUser: function (request, response) {
        var authValues = request.headers.authorization;
        var credentials = authValues.split(' ')[1];
        var data = credentials.split(':');
        var userName = data[0];
        var password = data[1];
        if (userName === "one" && password === "one") {
            return true;

        }
    },
    userRegistration: function () {
        return Products;
    }
};