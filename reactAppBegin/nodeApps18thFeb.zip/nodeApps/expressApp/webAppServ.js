//1. load express
var express = require('express');
//1a. load the path module. This will be used by static middleware of express. The 'path' is standard node module
var path = require("path")

//1b. import the data-model
var dataModel = require("./dataModel")
var userModel = require("./userModel")
var dalModel = require("./dal")
//1c. load the body-parser
var bodyparser = require("body-parser")

//1d,. Load the mongoose driver
var mongoose = require('mongoose')

//1e. set the global promise to magae all sync calls made by application using mongoose driver
mongoose.Promise = global.Promise;

//2. define an instance of express
var instance = express();

//3. configure all middlewares, call "use()" method on express instance
//3a. statis files
instance.use(
    express.static(
        path.join(__dirname, './../node_modules/jquery/dist/')
    )
);
//3b. define express router for seggrigating urls for html page web requests and rest api requests.
var router = express.Router();
//3c. Add the router object in the express middleware.
instance.use(router);
//3d. configure the body-parser middleware
//3d.1 use urlencoded as false to read data from http url as querystring, formmodel etc.
instance.use(bodyparser.urlencoded({ extended: false }));
//3d.2 Use the json() parser for body parser
instance.use(bodyparser.json())
//4. create web request handlers.
//4a. This will return the home.html from views folder
/*instance.get("/home", function (req, resp) {
    resp.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    },
        function (error) {
            console.log("Resource not Found", + error.message);
        });
});*/

router.get("/home", function (req, resp) {
    resp.sendFile("home.html", {
        root: path.join(__dirname, "./../views")
    });
});

/**********************************************************************************************/

// 5. Model-Schema-Mapping with collection on Mongo DB and establishing connection with it.
mongoose.connect("mongodb://localhost/ProductsAppDB",
    { useNewUrlParser: true });
//5a. get the connection object
//if dbconnect is not undefined then the connection is successful.
var dbConnect = mongoose.connection;
if (!dbConnect) {
    console.log("Connection is not eastablished");
    return;
}

//5b. define schema (recommended to have same attributes as per the collections)
var productsSchema = mongoose.Schema({
    ProductId: Number,
    ProductName: String,
    CategoryName: String,
    Manufacturer: String,
    Price: Number
});

var userSchema = mongoose.Schema({
    userId: String,
    password: String,
});
//5c. map the schema with the collection
//                                   name        Schema        collection
var productModel = mongoose.model("Products", productsSchema, "Products")
var uModel = mongoose.model("UserModel", userSchema, "UserModel")
//6. create rest api request handlers

instance.get("/api/products", function (request, response) {
    //6a. make call to DB for a collection mapped with model and expect all documents from itt.
    productModel.find().exec(function (err, res) {
        //6b. if error occured the respond error
        if (err) {
            response.statusCode = 500;
            response.send({ status: response.statusCode, error: err })
        }
        dalModel.getProductArray(res);
        response.send({ status: 200, data: res })
    });
});

instance.get("/api/usermodel", function (request, response) {
    //6a. make call to DB for a collection mapped with model and expect all documents from itt.
    uModel.find().exec(function (err, res) {
        //6b. if error occured the respond error
        if (err) {
            response.statusCode = 500;
            response.send({ status: response.statusCode, error: err })
        }
        response.send({ status: 200, data: res })
    });
});
/**********************************************************************************************/
instance.post("/api/products", function (request, response) {
    var prd = {
        ProductId: request.body.ProductId,
        ProductName: request.body.ProductName,
        CategoryName: request.body.CategoryName,
        Manufacturer: request.body.Manufacturer,
        Price: request.body.Price
    }

    //pass the parsed object to "create()" method
    productModel.create(prd, function (err, res) {
        if (err) {
            response.statusCode = 500;
            response.send({ status: response.statusCode, error: err })
        }
        response.send({ status: 200, data: res })
    });
});
//user model
instance.post("/api/usermodel", function (request, response) {

    var user = {
        userId: request.body.userId,
        password: request.body.password
    }
    // var data = userModel.validateUser(request, response)
    //5c. May access UserModel from Database(?)
    if (true) {
        dalModel.getAuthorizationStatus(true);
        //pass the parsed object to "create()" method
        uModel.create(user, function (err, res) {
            if (err) {
                response.statusCode = 500;
                response.send({ status: response.statusCode, error: err })
            }
            response.send({ status: 200, data: res })
        });
    } else {
        response.statusCode = 401;
        response.send({
            status: response.statusCode,
            message: "Please Login with Url of User registration"
        })
    }
});
// instance.post("/api/usermodel", function (request, response) {

// });

instance.get("/api/userModel", function (request, response) {
    //use params property of request object to read url parameter
    //  var data = userModel.validateUser(request, response)
    //5c. May access UserModel from Database(?)
    if (true) {
        dalModel.getAuthorizationStatus(true);
        var record = dataModel.getData();
        // return record;
        response.send(JSON.stringify(record));
    }
    console.log(JSON.stringify(record))
});

instance.get("/api/products/:id", function (request, response) {
    //use params property of request object to read url parameter
    var id = request.params.id;
    console.log("received id", id);
    var record = dataModel.getData().filter(function (v, idx) {
        return v.id == id;
    });
    console.log(JSON.stringify(record))
});

instance.put("/api/products/:id", function (request, response) {
    //read the request id parameter
    var pid = request.params.id;
    var pbody = request.body;
    //read the body
    //update matched record from array
    var record = dataModel.updateData(pbody)
    response.send(JSON.stringify(record));
    return pid;
});
instance.delete("/api/products/:id", function (request, response) {
    var did = request.params.id;
    var dbody = request.params.body;
    //read the body
    //update matched record from array
    var record = dataModel.deleteData(did)

    response.send(JSON.stringify(record));
});
//6. start listening
instance.listen(4070, function () {
    console.log("start listening on port 4070")
})
