var fs = require('fs');
//1. Write file using async call

fs.writeFile("./myAsyncFile.txt", "I am the Async text file",
    function (err) {
        if (err) {
            console.log(err.message);
            return;
        }
        console.log('File returned successfully...');
        fs.readFile("./myAsyncFile.txt", function (err, data) {
            if (err) {
                console.log("error", err.message);
                return;
            }
            console.log("data", data.toString());
        })
        //  fs.mappdir("./makeDirectory.txt",)
        // to append the data to existing file
        fs.appendFile("./myAsyncFile.txt", " I am the added one", function (err) {
            if (err) {
                console.log("error", err.message);
                return;
            }

        });
        // mkdir() to create new file within a project directory
        fs.mkdir("./myNewFile.txt", function (err) {
            if (err) {
                console.log("error", err.message);
                return;
            }

        });
        // rmdir to remove the exisiting file
        fs.rmdir("./myNewFile.txt", function (err) {
            if (err) {
                console.log("error", err.message);
                return;
            }

        });
    });
console.log("Done")
