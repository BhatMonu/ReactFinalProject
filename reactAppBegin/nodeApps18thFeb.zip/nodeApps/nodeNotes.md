**Programming with Node.js**

- server-side javascript
  - node modules
    - Standard node.js object model with pre-defined set of classes
  - Standard Modules
  - Developer designed custom modules
  - External node.js application odules
    -https://www.npmjs.com

**Node.js standard modules**
- http
    - http2
    - http
        - define server
            - createServer(HttpRequestListner)
                - HttpRequestListner --> CallBack(Request, Response)
                    - Request
                        - Uri property, used to read the requested uri for routing.
                    - Response
                        - writeHead() --> write response header values
                            - Content-Type
                                - text/html
                                - application/json
                                - image/bmp or image/jpg, image/png
                        - write() --> Data to be written in Http body
                        - end() --> Send response and close the Http Session
        - define client for externally hosted services
            - createClient()
- path
- fs
    - file system management on Node.js server for current application.
        - readFile() --> Async
        - readFileSync()
        - writeFIle() --> Async
        - writeFileSync() 
- util

**Module Loading**
- The "require('<MODULE-NAME>')" object.
    - The 'MODULE-NAME' must be present in the present/current scope.
        - Custom Module
        - Standard Module
        - External module must be installed
    - The "require()" will cache the module for current workspace.