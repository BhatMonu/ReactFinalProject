
var callModule = require('./productModule');
var http = require('http');
var fs = require('fs');
const {
    parse
} = require('querystring');

console.log('Done');
var productArray = [];
var finalProductData = [];
var ServerOptions = {
    host: 'apiapptrainingservice.azurewebsites.net',
    path: '/api/Products',
    method: 'GET'
};
//"ProductRowId":6,"ProductId":"10034","ProductName":"LAPTOP","Manufacturer":"DEL","CategoryName":"Electronics","Description":"Testing ...","BasePrice":52000}
callModule.getData(ServerOptions).then(function (response) {

    console.log("ProductId\tProductName\tManufacturer\tCategoryName\tDescription\ttBasePrice");
    console.log();
    for (var i = 0; i < response.length; i++) {
        console.log(response[i].ProductId + "\t" + response[i].ProductName + "\t\t" + response[i].Manufacturer + "\t" + response[i].CategoryName + "\t\t" + response[i].Description + "\t" + response.BasePrice);
    }
}).catch(function (err) {
    console.log(err);
});
3.
function get() {
    http.request(ServerOptions, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (data) {
            productArray = JSON.parse(data);
            console.log(JSON.stringify(productArray));
            productArray.map((data, index) => {
                console.log(JSON.stringify(data));
            });
        });

    }).end();
}
//"ProductRowId":6,"ProductId":"10034","ProductName":"LAPTOP","Manufacturer":"DEL","CategoryName":"Electronics","Description":"Testing ...","BasePrice":52000}

console.log("Doing the Post Operations....");
//4


function post(finalProductDataArray) {
    var dataToBeSent = JSON.stringify({

        'ProductId': finalProductDataArray.pid,
        'ProductName': finalProductDataArray.pname,
        'Manufacturer': finalProductDataArray.pmanufacturer,
        'CategoryName': finalProductDataArray.pcname,
        'Description': finalProductDataArray.pdesc,
        'BasePrice': finalProductDataArray.pbprice
    });


    //5
    var ServerOptionsPost = {
        host: 'apiapptrainingservice.azurewebsites.net',
        path: '/api/Products',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': dataToBeSent.length,

        }
    };
    var reqPost = http.request(ServerOptionsPost, function (res) {
        console.log("response statusCode: ", res.statusCode);
        res.on('data', function (data) {
            console.log('Posting Result:\n');
            process.stdout.write(data);
            console.log('\n\nPOST Operation Completed');
        });
    });

    // 7
    reqPost.write(finalProductDataArray);
    reqPost.end();
    reqPost.on('error', function (e) {
        console.error(e);
    });

}




//6

get();
var productPage = fs.readFileSync('./products.html');
// fs.readFile('./products.html', function (err, data) {
//     resp.writeHead(200, { 'Content-Type': 'text/html' });
//     resp.write(data);
//     console.log("data...............", data);

//     return resp.end();
// });
//console.log("productPage", JSON.stringify(productPage));

//3.
var server = http.createServer(function (req, resp) {

    //4.
    if (req.method === "GET") {
        get();
        resp.writeHead(200, {
            'content-type': 'text/html'
        });
        resp.end(productPage);
    }
    //5.
    if (req.method === "POST") {

        var productData = '';
        //6.
        req.on('data', function (prd) {
            productData += prd;
        }).on('end', function () {

            finalProductData = parse(productData);
            // post(finalProductData);
            console.log("The received data is", finalProductData);
            // console.log('The received data is ' + productData.toString());
            ////   resp.end('Data received  from you is ' + productData.toString());
        });
    }
});
server.listen(5050);
console.log('Server started on  5050');