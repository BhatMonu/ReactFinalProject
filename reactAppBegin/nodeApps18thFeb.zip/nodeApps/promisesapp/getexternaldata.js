//1. Load q
var q = require("q");

//2. Load http to make external calls
var http = require("http");

//3. define module
module.exports = {
    //3a. function to make http calls using "http" object
    //this function must accept server information
    //server info will be a.)host, b.) path, c.) method
    //host --> host address IP/name
    //path --> uri path aka resource name or REST-API address
    //method --> GET?POST?PUT?DELETE
    //headers --> {AUTHORIZATION}
    //this function will return 'promise'
    //if the method receive sucess the defer will
    //resolve else reject
    getData: function (options) {
        //4. Create deferrer object using q
        var defer = q.defer();
        var request;
        var response; // represent response
        var responseData; // represent response data

        if (!options) {
            defer.reject("Server information is not available");
        } else {
            request = http.request(options, function (response) {
                //4a. start receiving data
                response.on('data', function (data) {
                    responseData += data;
                });
                console.log("DATA", JSON.stringify(responseData));

                // 4b. once data processing is done end the call
                response.on("end", function (data) {
                    try {
                        //if end successfully the resolve
                        var responseData = JSON.parse(responseData);
                        defer.resolve(responseData)
                    } catch (err) {
                        // else reject and return error
                        defer.reject(`some error occurred ${err}`)
                    }
                });
            });
        }
        //5. end the response
        request.end();
        //6. return the promise
        return defer.promise;
    }
}