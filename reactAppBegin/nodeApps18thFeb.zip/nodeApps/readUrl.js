

var http = require('http');
var fs = require("fs")
var page = "";
var UrlsArray = [{
    Url: "/home",
    file: "./home.html"
},
{
    Url: "/about",
    file: "./about.html"
},
{
    Url: "/contact",
    file: "./contact.html"
},
]

var server = http.createServer(function (request, response) {
    for (i = 0; i >= UrlsArray.length; i++) {
        if (request.url === UrlsArray[i].Url) {
            page = UrlsArray[i].file;
            console.log(page);

        }
    }
    //2a. read for home page
    fs.readFile(page.toString(), function (err, data) {
        if (err) {
            response.writeHead(401, { "Content-Type": "text.html" });
            response.write("resourse is not available");
            response.end();
        } else {

        }
        response.writeHead(200, { "Content-Type": "text/html" });
        response.write(data);

    });
    //parse the request and read the url

});

server.listen(4060);
console.log("Server Started on port 4060");